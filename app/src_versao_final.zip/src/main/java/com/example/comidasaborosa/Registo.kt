package com.example.comidasaborosa

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.comidasaborosa.retrofit.RetrofitInitializer
import com.example.comidasaborosa.retrofit.service.SheetyLoginResponse
import com.example.comidasaborosa.retrofit.service.SheetyUserCreatedResponse
import com.example.comidasaborosa.retrofit.service.UserCreateRequest
import com.example.comidasaborosa.retrofit.service.UserCreateWrapper
import com.example.comidasaborosa.util.ValidationUtils
import com.google.gson.Gson
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class Registo : AppCompatActivity() {

    private lateinit var editTextName: EditText
    private lateinit var editTextEmail: EditText
    private lateinit var editTextPassword: EditText
    private lateinit var editTextConfirmPassword: EditText
    private lateinit var btnRegister: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registo)

        // Inicializar todos os campos de entrada
        editTextName = findViewById(R.id.inputUserName)
        editTextEmail = findViewById(R.id.inputEmail)
        editTextPassword = findViewById(R.id.inputPassword)
        editTextConfirmPassword = findViewById(R.id.confirmPassword)
        btnRegister = findViewById(R.id.btnRegisto)

        btnRegister.setOnClickListener {
            val name = editTextName.text.toString().trim()
            val email = editTextEmail.text.toString().trim()
            val password = editTextPassword.text.toString().trim()
            val confirmPassword = editTextConfirmPassword.text.toString().trim()

            // Validar todos os inputs antes de enviar
            if (validateAllInputs(name, email, password, confirmPassword)) {
                // Desabilitar o botão durante o registro para evitar múltiplos cliques
                btnRegister.isEnabled = false
                btnRegister.text = "A registar..."

                // Verificar se o email já existe antes de registrar
                checkEmailAndRegister(name, email, password)
            }
        }

        // Texto para fazer login
        val fazerLoginTextView: TextView = findViewById(R.id.conta)
        fazerLoginTextView.setOnClickListener {
            val intent = Intent(this, Login::class.java)
            startActivity(intent)
        }
    }

    private fun validateAllInputs(name: String, email: String, password: String, confirmPassword: String): Boolean {
        // Limpar erros anteriores
        editTextName.error = null
        editTextEmail.error = null
        editTextPassword.error = null
        editTextConfirmPassword.error = null

        var isValid = true

        // Validar nome usando ValidationUtils
        when {
            !ValidationUtils.isValidName(name) -> {
                editTextName.error = when {
                    name.isEmpty() -> "Nome é obrigatório"
                    name.length < 2 -> "Nome deve ter pelo menos 2 caracteres"
                    name.length > 100 -> "Nome demasiado longo"
                    else -> "Nome deve conter apenas letras"
                }
                editTextName.requestFocus()
                isValid = false
            }
        }

        // Validar email usando ValidationUtils
        when {
            !ValidationUtils.isValidEmail(email) -> {
                editTextEmail.error = when {
                    email.isEmpty() -> "Email é obrigatório"
                    email.length > 100 -> "Email demasiado longo"
                    else -> "Email inválido"
                }
                if (isValid) editTextEmail.requestFocus()
                isValid = false
            }
        }

        // Validar senha usando ValidationUtils
        when {
            !ValidationUtils.isValidPassword(password) -> {
                editTextPassword.error = when {
                    password.isEmpty() -> "Senha é obrigatória"
                    password.length < 6 -> "Senha deve ter pelo menos 6 caracteres"
                    password.length > 50 -> "Senha demasiado longa"
                    password.contains(" ") -> "Senha não pode conter espaços"
                    else -> "Senha inválida"
                }
                if (isValid) editTextPassword.requestFocus()
                isValid = false
            }
        }

        // Validar confirmação de senha
        when {
            confirmPassword.isEmpty() -> {
                editTextConfirmPassword.error = "Confirmação de senha é obrigatória"
                if (isValid) editTextConfirmPassword.requestFocus()
                isValid = false
            }
            confirmPassword != password -> {
                editTextConfirmPassword.error = "As senhas não coincidem"
                if (isValid) editTextConfirmPassword.requestFocus()
                isValid = false
            }
        }

        return isValid
    }

    private fun checkEmailAndRegister(name: String, email: String, password: String) {
        // Primeiro, verificar se o email já está registrado
        val call = RetrofitInitializer().sheetyService().getAllUsers()

        call.enqueue(object : Callback<SheetyLoginResponse> {
            override fun onResponse(call: Call<SheetyLoginResponse>, response: Response<SheetyLoginResponse>) {
                if (response.isSuccessful) {
                    val users = response.body()?.utilizador ?: emptyList()
                    val emailExists = users.any { it.email.equals(email, ignoreCase = true) }

                    if (emailExists) {
                        btnRegister.isEnabled = true
                        btnRegister.text = getString(R.string.btn_registo)
                        editTextEmail.error = "Este email já está registrado"
                        editTextEmail.requestFocus()
                    } else {
                        // Email não existe, prosseguir com o registro
                        performRegistration(name, email, password)
                    }
                } else {
                    // Se falhar a verificação, tentar registrar mesmo assim
                    performRegistration(name, email, password)
                }
            }

            override fun onFailure(call: Call<SheetyLoginResponse>, t: Throwable) {
                // Se falhar a verificação, tentar registrar mesmo assim
                performRegistration(name, email, password)
            }
        })
    }

    private fun performRegistration(name: String, email: String, password: String) {
        // Sanitizar inputs
        val sanitizedName = ValidationUtils.sanitizeInput(name)
        val sanitizedEmail = ValidationUtils.sanitizeInput(email)
        val sanitizedPassword = ValidationUtils.sanitizeInput(password)

        // Criar objeto UserCreateRequest (SEM ID)
        val userCreateRequest = UserCreateRequest(
            nome = sanitizedName,
            email = sanitizedEmail,
            senha = sanitizedPassword
        )

        val request = UserCreateWrapper(userCreateRequest)

        // Log dos dados sendo enviados
        Log.d("Registo", "Enviando registro para Sheety...")

        Log.d("Registo", "Dados JSON: ${Gson().toJson(request)}")

        val call = RetrofitInitializer().sheetyService().createUser(request)

        call.enqueue(object : Callback<SheetyUserCreatedResponse> {
            override fun onResponse(call: Call<SheetyUserCreatedResponse>, response: Response<SheetyUserCreatedResponse>) {
                // Reabilitar o botão
                btnRegister.isEnabled = true
                btnRegister.text = getString(R.string.btn_registo)

                Log.d("Registo", "Resposta recebida - Código: ${response.code()}")
                Log.d("Registo", "Headers: ${response.headers()}")

                when {
                    response.isSuccessful -> {
                        Log.d("Registo", "Registro bem-sucedido!")
                        val userResponse = response.body()
                        Log.d("Registo", "Dados retornados: $userResponse")

                        Toast.makeText(this@Registo, "Registro realizado com sucesso!", Toast.LENGTH_LONG).show()

                        // Limpar os campos
                        editTextName.text.clear()
                        editTextEmail.text.clear()
                        editTextPassword.text.clear()
                        editTextConfirmPassword.text.clear()

                        // Redirecionar para o login após um pequeno delay
                        btnRegister.postDelayed({
                            val intent = Intent(this@Registo, Login::class.java)
                            startActivity(intent)
                            finish()
                        }, 1500)
                    }
                    response.code() == 400 -> {
                        val errorBody = response.errorBody()?.string()
                        Log.e("Registo", "Erro 400 - Body: $errorBody")
                        Toast.makeText(
                            this@Registo,
                            "Erro no formato dos dados. Verifique os campos.",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                    response.code() == 401 || response.code() == 403 -> {
                        Toast.makeText(
                            this@Registo,
                            "Erro de autenticação. Verifique a configuração da API.",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                    response.code() == 409 -> {
                        editTextEmail.error = "Este email já está registrado"
                        editTextEmail.requestFocus()
                    }
                    response.code() == 500 -> {
                        Toast.makeText(
                            this@Registo,
                            "Erro no servidor. Tente novamente mais tarde.",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                    else -> {
                        val errorBody = response.errorBody()?.string()
                        Log.e("Registo", "Erro ${response.code()} - Body: $errorBody")
                        Toast.makeText(
                            this@Registo,
                            "Erro no registro: ${response.code()}",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }
            }

            override fun onFailure(call: Call<SheetyUserCreatedResponse>, t: Throwable) {
                // Reabilitar o botão em caso de falha
                btnRegister.isEnabled = true
                btnRegister.text = getString(R.string.btn_registo)

                Log.e("Registo", "Falha na conexão", t)

                val errorMessage = when {
                    t.message?.contains("timeout", true) == true ->
                        "Tempo de conexão esgotado. Verifique sua internet."
                    t.message?.contains("connection", true) == true ->
                        "Sem conexão com a internet."
                    else -> "Falha na conexão: ${t.localizedMessage}"
                }

                Toast.makeText(this@Registo, errorMessage, Toast.LENGTH_LONG).show()
            }
        })
    }
}
