package com.example.comidasaborosa.fragmentos

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.comidasaborosa.CarrinhoManager
import com.example.comidasaborosa.R
import com.example.comidasaborosa.util.UserPreferences

class FragmentoCarro : Fragment() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var textTotal: TextView
    private lateinit var btnFinalizar: Button
    private lateinit var progressBar: ProgressBar
    private lateinit var emptyView: TextView

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragmento_carro, container, false)
        setupViews(view)
        return view
    }

    private fun setupViews(view: View) {
        recyclerView = view.findViewById(R.id.recyclerViewCarrinho)
        textTotal = view.findViewById(R.id.textTotal)
        btnFinalizar = view.findViewById(R.id.btnFinalizar)
        progressBar = view.findViewById(R.id.progressBar)
        emptyView = view.findViewById(R.id.emptyView)

        recyclerView.layoutManager = LinearLayoutManager(context)
        btnFinalizar.setOnClickListener { finalizarCompra() }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initUserPreferences()
        verificarLoginECarregarCarrinho()
    }

    override fun onResume() {
        super.onResume()
        verificarLoginECarregarCarrinho()
    }

    private fun initUserPreferences() {
        context?.let {
            if (!UserPreferences.isInitialized()) {
                UserPreferences.init(it)
            }
        }
    }

    private fun verificarLoginECarregarCarrinho() {
        if (!UserPreferences.isLoggedIn()) {
            showEmptyState("Faça login para aceder ao carrinho")
        } else {
            carregarCarrinhoDoServidor()
        }
    }

    private fun carregarCarrinhoDoServidor() {
        showLoading(true)
        CarrinhoManager.carregarCarrinho { success ->
            activity?.runOnUiThread {
                showLoading(false)
                if (success) {
                    atualizarCarrinho()
                } else {
                    showErrorState()
                }
            }
        }
    }

    private fun atualizarCarrinho() {
        val itens = CarrinhoManager.getItens()
        if (itens.isEmpty()) {
            showEmptyState("Carrinho vazio")
        } else {
            showCartContents(itens)
        }
    }

    private fun showLoading(show: Boolean) {
        progressBar.visibility = if (show) View.VISIBLE else View.GONE
        recyclerView.visibility = if (show) View.GONE else View.VISIBLE
        btnFinalizar.isEnabled = !show
    }

    // Estados da UI
    private fun showEmptyState(message: String) {
        recyclerView.visibility = View.GONE
        emptyView.visibility = View.VISIBLE
        emptyView.text = message
        btnFinalizar.isEnabled = false
        textTotal.text = "Total: €0,00"
    }

    private fun showErrorState() {
        Toast.makeText(context, "Erro ao carregar carrinho", Toast.LENGTH_SHORT).show()
        emptyView.visibility = View.VISIBLE
        emptyView.text = "Erro ao carregar carrinho. Tente novamente."
    }

    private fun showCartContents(items: List<CarrinhoManager.CarrinhoItemWithId>) {
        recyclerView.visibility = View.VISIBLE
        emptyView.visibility = View.GONE
        btnFinalizar.isEnabled = true
        recyclerView.adapter = CarrinhoAdapter(items)
        updateTotal()
    }

    private fun updateTotal() {
        val total = CarrinhoManager.calcularTotal()
        textTotal.text = "Total: €%.2f".format(total)
    }

    // Finalização de compra
    private fun finalizarCompra() {
        if (CarrinhoManager.getItens().isEmpty()) return

        AlertDialog.Builder(requireContext())
            .setTitle("Finalizar Compra")
            .setMessage("Deseja realmente finalizar a compra?")
            .setPositiveButton("Sim") { _, _ -> processarCompra() }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun processarCompra() {
        showLoading(true)
        CarrinhoManager.finalizarPedido { success ->
            activity?.runOnUiThread {
                showLoading(false)
                val message = if (success) "Pedido enviado com sucesso!"
                else "Erro ao enviar pedido. Tente novamente."

                Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
                atualizarCarrinho()
            }
        }
    }

    // Adapter e ViewHolder para o RecyclerView
    inner class CarrinhoAdapter(
        private val items: List<CarrinhoManager.CarrinhoItemWithId>
    ) : RecyclerView.Adapter<CarrinhoViewHolder>() {

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
            CarrinhoViewHolder(
                LayoutInflater.from(parent.context)
                    .inflate(R.layout.item_carrinho, parent, false)
            )

        override fun onBindViewHolder(holder: CarrinhoViewHolder, position: Int) {
            holder.bind(items[position])
        }

        override fun getItemCount() = items.size
    }

    inner class CarrinhoViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val textNome: TextView = itemView.findViewById(R.id.textNome)
        private val textPreco: TextView = itemView.findViewById(R.id.textPreco)
        private val textQuantidade: TextView = itemView.findViewById(R.id.textQuantidadeValue)
        private val btnRemover: Button = itemView.findViewById(R.id.btnRemover)
        private val btnMais: Button = itemView.findViewById(R.id.btnMais)
        private val btnMenos: Button = itemView.findViewById(R.id.btnMenos)

        fun bind(item: CarrinhoManager.CarrinhoItemWithId) {
            textNome.text = item.menu.nome ?: "Item sem nome"
            updatePriceDisplay(item)
            textQuantidade.text = item.quantidade.toString()

            setupQuantityButtons(item)
            setupRemoveButton(item)
        }

        private fun updatePriceDisplay(item: CarrinhoManager.CarrinhoItemWithId) {
            val totalItem = (item.menu.preco ?: 0.0) * item.quantidade
            textPreco.text = "€%.2f".format(totalItem)
        }

        private fun setupQuantityButtons(item: CarrinhoManager.CarrinhoItemWithId) {
            btnMais.setOnClickListener { changeQuantity(item, item.quantidade + 1) }
            btnMenos.setOnClickListener {
                if (item.quantidade > 1) changeQuantity(item, item.quantidade - 1)
            }
        }

        private fun changeQuantity(item: CarrinhoManager.CarrinhoItemWithId, newQuantity: Int) {
            CarrinhoManager.atualizarQuantidade(item, newQuantity) { success ->
                activity?.runOnUiThread {
                    if (success) {
                        item.quantidade = newQuantity
                        textQuantidade.text = newQuantity.toString()
                        updatePriceDisplay(item)
                        updateTotal()
                    }
                }
            }
        }

        private fun setupRemoveButton(item: CarrinhoManager.CarrinhoItemWithId) {
            btnRemover.setOnClickListener {
                AlertDialog.Builder(requireContext())
                    .setTitle("Remover Item")
                    .setMessage("Confirmar remoção de ${item.menu.nome}?")
                    .setPositiveButton("Sim") { _, _ -> removeItem(item) }
                    .setNegativeButton("Cancelar", null)
                    .show()
            }
        }

        private fun removeItem(item: CarrinhoManager.CarrinhoItemWithId) {
            showLoading(true)
            CarrinhoManager.removerItem(item.menu) { success ->
                activity?.runOnUiThread {
                    showLoading(false)
                    if (success) {
                        Toast.makeText(context, "Item removido", Toast.LENGTH_SHORT).show()
                        atualizarCarrinho()
                    }
                }
            }
        }
    }

    companion object {
        fun newInstance() = FragmentoCarro()
    }
}
