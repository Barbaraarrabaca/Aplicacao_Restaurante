package com.example.comidasaborosa

import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.example.comidasaborosa.model.Menu
import com.example.comidasaborosa.retrofit.RetrofitHelper
import com.example.comidasaborosa.retrofit.service.CarrinhoCreateItem
import com.example.comidasaborosa.retrofit.service.CarrinhoUpdateItem
import com.example.comidasaborosa.retrofit.service.PedidoCreate
import com.example.comidasaborosa.retrofit.service.PedidoCreateRequest
import com.example.comidasaborosa.retrofit.service.SheetyCarrinhoListResponse
import com.example.comidasaborosa.retrofit.service.SheetyCarrinhoRequest
import com.example.comidasaborosa.retrofit.service.SheetyCarrinhoResponse
import com.example.comidasaborosa.retrofit.service.SheetyCarrinhoUpdateRequest
import com.example.comidasaborosa.retrofit.service.SheetyPedidoResponse
import com.example.comidasaborosa.retrofit.service.SheetyService
import com.example.comidasaborosa.util.UserPreferences
import com.google.gson.Gson
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicInteger

object CarrinhoManager {
    private val itensCarrinho = mutableListOf<CarrinhoItemWithId>()
    private val sheetyService = RetrofitHelper.getInstance().create(SheetyService::class.java)
    private val gson = Gson()
    private val handler = Handler(Looper.getMainLooper())

    // LiveData para notificar mudanças
    private val _carrinhoChanged = MutableLiveData<Boolean>()
    val carrinhoChanged: LiveData<Boolean> = _carrinhoChanged

    data class CarrinhoItemWithId(
        val id: Int,
        val menu: Menu,
        var quantidade: Int = 1
    )

    data class ItemPedido(
        val itemId: Int,
        val nome: String,
        val preco: Double,
        val quantidade: Int
    )

    // Método para notificar mudanças
    private fun notifyChange() {
        _carrinhoChanged.postValue(true)
    }

    // ==================== [CORE METHODS] ====================
    fun carregarCarrinho(onComplete: (Boolean) -> Unit) {
        val userId = UserPreferences.getUserId().takeIf { it != -1 } ?: run {
            onComplete(false)
            return
        }

        sheetyService.getAllCarrinhoItems().enqueue(object : Callback<SheetyCarrinhoListResponse> {
            override fun onResponse(
                call: Call<SheetyCarrinhoListResponse>,
                response: Response<SheetyCarrinhoListResponse>
            ) {
                if (response.isSuccessful) {
                    itensCarrinho.clear()
                    response.body()?.carrinho
                        ?.filter { it.userId == userId }
                        ?.forEach { item ->
                            val menu = Menu(
                                id = item.itemId,
                                nome = item.nome,
                                preco = item.preco,
                                descricao = "",
                                categoria = "",
                                imagem = ""
                            )
                            itensCarrinho.add(
                                CarrinhoItemWithId(
                                    id = item.id,
                                    menu = menu,
                                    quantidade = item.quantidade
                                )
                            )
                        }
                    notifyChange() // Notifica mudanças após carregar
                    onComplete(true)
                } else {
                    Log.e("CarrinhoManager", "Erro ao carregar: ${response.code()}")
                    onComplete(false)
                }
            }

            override fun onFailure(call: Call<SheetyCarrinhoListResponse>, t: Throwable) {
                Log.e("CarrinhoManager", "Falha de rede: ${t.message}")
                onComplete(false)
            }
        })
    }

    // ==================== [ITEM OPERATIONS] ====================
    fun adicionarItem(item: Menu, onComplete: (Boolean) -> Unit = {}) {
        val userId = UserPreferences.getUserId()
        if (userId == -1) {
            onComplete(false)
            return
        }

        itensCarrinho.find { it.menu.id == item.id }?.let {
            atualizarQuantidade(it, it.quantidade + 1, onComplete)
        } ?: criarNovoItem(item, onComplete)
    }

    fun removerItem(item: Menu, onComplete: (Boolean) -> Unit = {}) {
        itensCarrinho.find { it.menu.id == item.id }?.let {
            removerItemPorId(it.id, onComplete)
        } ?: onComplete(false)
    }

    fun atualizarQuantidade(item: CarrinhoItemWithId, novaQuantidade: Int, onComplete: (Boolean) -> Unit) {
        if (novaQuantidade < 1) {
            removerItemPorId(item.id, onComplete)
            return
        }

        val updateRequest = SheetyCarrinhoUpdateRequest(CarrinhoUpdateItem(novaQuantidade))
        sheetyService.updateCarrinhoItem(item.id, updateRequest).enqueue(object : Callback<SheetyCarrinhoResponse> {
            override fun onResponse(call: Call<SheetyCarrinhoResponse>, response: Response<SheetyCarrinhoResponse>) {
                if (response.isSuccessful) {
                    item.quantidade = novaQuantidade
                    notifyChange() // Notifica mudanças após atualizar quantidade
                    onComplete(true)
                } else {
                    onComplete(false)
                }
            }

            override fun onFailure(call: Call<SheetyCarrinhoResponse>, t: Throwable) {
                Log.e("CarrinhoManager", "Erro atualizar quantidade: ${t.message}")
                onComplete(false)
            }
        })
    }

    // ==================== [CHECKOUT SYSTEM] ====================
    fun finalizarPedido(onComplete: (Boolean) -> Unit) {
        val userId = UserPreferences.getUserId().takeIf { it != -1 } ?: run {
            onComplete(false)
            return
        }

        if (itensCarrinho.isEmpty()) {
            onComplete(false)
            return
        }

        criarPedido(userId, onComplete)
    }

    // ==================== [HELPER METHODS] ====================
    fun getItens(): List<CarrinhoItemWithId> = itensCarrinho.toList()

    fun calcularTotal(): Double = itensCarrinho.sumOf { (it.menu.preco ?: 0.0) * it.quantidade }

    fun getQuantidadeItem(menuId: Int): Int =
        itensCarrinho.find { it.menu.id == menuId }?.quantidade ?: 0

    // ==================== [PRIVATE METHODS] ====================
    private fun criarNovoItem(item: Menu, onComplete: (Boolean) -> Unit) {
        val carrinhoItem = CarrinhoCreateItem(
            userId = UserPreferences.getUserId(),
            itemId = item.id ?: 0,
            nome = item.nome ?: "",
            preco = item.preco ?: 0.0,
            quantidade = 1
        )

        sheetyService.addItemToCarrinho(SheetyCarrinhoRequest(carrinhoItem)).enqueue(object : Callback<SheetyCarrinhoResponse> {
            override fun onResponse(call: Call<SheetyCarrinhoResponse>, response: Response<SheetyCarrinhoResponse>) {
                if (response.isSuccessful) {
                    response.body()?.let {
                        itensCarrinho.add(CarrinhoItemWithId(it.carrinho.id, item, it.carrinho.quantidade))
                        notifyChange() // Notifica mudanças após adicionar item
                    }
                    onComplete(true)
                } else {
                    onComplete(false)
                }
            }

            override fun onFailure(call: Call<SheetyCarrinhoResponse>, t: Throwable) {
                Log.e("CarrinhoManager", "Erro ao adicionar item: ${t.message}")
                onComplete(false)
            }
        })
    }

    private fun removerItemPorId(id: Int, onComplete: (Boolean) -> Unit, tentativasRestantes: Int = 3) {
        sheetyService.removeItemFromCarrinho(id).enqueue(object : Callback<Void> {
            override fun onResponse(call: Call<Void>, response: Response<Void>) {
                if (response.isSuccessful) {
                    itensCarrinho.removeIf { it.id == id }
                    notifyChange() // Notifica mudanças após remover item
                    onComplete(true)
                } else if (tentativasRestantes > 0) {
                    handler.postDelayed({ removerItemPorId(id, onComplete, tentativasRestantes - 1) }, 1000)
                } else {
                    onComplete(false)
                }
            }

            override fun onFailure(call: Call<Void>, t: Throwable) {
                if (tentativasRestantes > 0) {
                    handler.postDelayed({ removerItemPorId(id, onComplete, tentativasRestantes - 1) }, 1000)
                } else {
                    onComplete(false)
                }
            }
        })
    }

    private fun criarPedido(userId: Int, onComplete: (Boolean) -> Unit) {
        val pedido = PedidoCreate(
            userId = userId,
            dataHora = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date()),
            total = calcularTotal(),
            status = "pendente",
            itens = gson.toJson(itensCarrinho.map {
                ItemPedido(it.menu.id ?: 0, it.menu.nome ?: "", it.menu.preco ?: 0.0, it.quantidade)
            })
        )

        sheetyService.criarPedido(PedidoCreateRequest(pedido)).enqueue(object : Callback<SheetyPedidoResponse> {
            override fun onResponse(call: Call<SheetyPedidoResponse>, response: Response<SheetyPedidoResponse>) {
                if (response.isSuccessful) {
                    limparCarrinhoRemoto(userId, onComplete)
                } else {
                    onComplete(false)
                }
            }

            override fun onFailure(call: Call<SheetyPedidoResponse>, t: Throwable) {
                onComplete(false)
            }
        })
    }

    private fun limparCarrinhoRemoto(userId: Int, onComplete: (Boolean) -> Unit) {
        sheetyService.getAllCarrinhoItems().enqueue(object : Callback<SheetyCarrinhoListResponse> {
            override fun onResponse(call: Call<SheetyCarrinhoListResponse>, response: Response<SheetyCarrinhoListResponse>) {
                response.body()?.carrinho
                    ?.filter { it.userId == userId }
                    ?.map { it.id }
                    ?.takeIf { it.isNotEmpty() }
                    ?.let { apagarItensComTentativas(it, onComplete) }
                    ?: onComplete(true)
            }

            override fun onFailure(call: Call<SheetyCarrinhoListResponse>, t: Throwable) {
                onComplete(false)
            }
        })
    }

    // ==================== [CORREÇÃO DO ERRO] ====================
    private fun apagarItensComTentativas(ids: List<Int>, onComplete: (Boolean) -> Unit) {
        val attempts = AtomicInteger(0)
        val remaining = AtomicInteger(ids.size)
        var tentativasRestantes = 3

        fun processarLote() {
            remaining.set(ids.size)
            ids.forEach { id ->
                sheetyService.removeItemFromCarrinho(id).enqueue(object : Callback<Void> {
                    override fun onResponse(call: Call<Void>, response: Response<Void>) {
                        if (response.isSuccessful) {
                            itensCarrinho.removeIf { it.id == id }
                        }
                        remaining.decrementAndGet()
                        if (remaining.get() == 0) {
                            val todosRemovidos = ids.all { id -> itensCarrinho.none { it.id == id } }

                            when {
                                todosRemovidos -> {
                                    notifyChange() // Notifica mudanças após limpar carrinho
                                    onComplete(true)
                                }
                                tentativasRestantes > 0 -> {
                                    tentativasRestantes--
                                    attempts.incrementAndGet()
                                    handler.postDelayed(::processarLote, 2000)
                                }
                                else -> onComplete(false)
                            }
                        }
                    }

                    override fun onFailure(call: Call<Void>, t: Throwable) {
                        remaining.decrementAndGet()
                        if (remaining.get() == 0) {
                            val todosRemovidos = ids.all { id -> itensCarrinho.none { it.id == id } }

                            when {
                                todosRemovidos -> {
                                    notifyChange() // Notifica mudanças após limpar carrinho
                                    onComplete(true)
                                }
                                tentativasRestantes > 0 -> {
                                    tentativasRestantes--
                                    attempts.incrementAndGet()
                                    handler.postDelayed(::processarLote, 2000)
                                }
                                else -> onComplete(false)
                            }
                        }
                    }
                })
            }
        }

        processarLote()
    }
}
