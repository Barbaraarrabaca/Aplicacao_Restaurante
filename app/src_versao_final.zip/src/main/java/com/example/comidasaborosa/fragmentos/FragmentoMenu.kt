package com.example.comidasaborosa.fragmentos

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.comidasaborosa.CarrinhoManager
import com.example.comidasaborosa.model.Menu
import com.example.comidasaborosa.R
import com.example.comidasaborosa.retrofit.RetrofitHelper
import com.example.comidasaborosa.retrofit.service.SheetyResponse
import com.example.comidasaborosa.retrofit.service.SheetyService
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class FragmentoMenu : Fragment() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var sheetyService: SheetyService
    private var menuList = mutableListOf<Menu>()
    private var menuAdapter: MenuAdapter? = null

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragmento_menu, container, false)
        initViews(view)
        setupRetrofit()
        loadMenuItems()
        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Observa mudanças no carrinho para atualizar a interface
        CarrinhoManager.carrinhoChanged.observe(viewLifecycleOwner) { _ ->
            // Atualiza apenas os itens visíveis para melhor performance
            updateVisibleItems()
        }

        // Carrega o carrinho inicialmente
        CarrinhoManager.carregarCarrinho { success ->
            if (success) {
                activity?.runOnUiThread {
                    menuAdapter?.notifyDataSetChanged()
                }
            }
        }
    }

    private fun initViews(view: View) {
        recyclerView = view.findViewById(R.id.recyclerViewMenu)
        recyclerView.layoutManager = LinearLayoutManager(requireContext())
        recyclerView.setHasFixedSize(true)
    }

    private fun setupRetrofit() {
        val retrofit = RetrofitHelper.getInstance()
        sheetyService = retrofit.create(SheetyService::class.java)
    }

    private fun loadMenuItems() {
        sheetyService.getAllMenuItems().enqueue(object : Callback<SheetyResponse> {
            override fun onResponse(call: Call<SheetyResponse>, response: Response<SheetyResponse>) {
                handleMenuResponse(response)
            }

            override fun onFailure(call: Call<SheetyResponse>, t: Throwable) {
                handleMenuError(t)
            }
        })
    }

    private fun handleMenuResponse(response: Response<SheetyResponse>) {
        if (response.isSuccessful) {
            response.body()?.menu?.let { items ->
                menuList.clear()
                menuList.addAll(items)
                menuAdapter = MenuAdapter(menuList)
                recyclerView.adapter = menuAdapter
            }
        } else {
            Log.e("API_ERROR", "Código: ${response.code()} - ${response.errorBody()?.string()}")
            showError("Erro ao carregar o menu")
        }
    }

    private fun handleMenuError(t: Throwable) {
        Log.e("NETWORK_ERROR", "Falha na rede", t)
        showError("Erro de conexão: ${t.message}")
    }

    private fun showError(message: String) {
        Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show()
    }

    // Atualiza apenas os itens visíveis para melhor performance
    private fun updateVisibleItems() {
        val layoutManager = recyclerView.layoutManager as? LinearLayoutManager ?: return
        val firstVisible = layoutManager.findFirstVisibleItemPosition()
        val lastVisible = layoutManager.findLastVisibleItemPosition()

        if (firstVisible != RecyclerView.NO_POSITION && lastVisible != RecyclerView.NO_POSITION) {
            menuAdapter?.notifyItemRangeChanged(firstVisible, lastVisible - firstVisible + 1)
        }
    }

    inner class MenuAdapter(private val items: List<Menu>) : RecyclerView.Adapter<MenuViewHolder>() {

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MenuViewHolder {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_menu, parent, false)
            return MenuViewHolder(view)
        }

        override fun onBindViewHolder(holder: MenuViewHolder, position: Int) {
            holder.bind(items[position])
        }

        override fun getItemCount() = items.size
    }

    inner class MenuViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        private val textNome: TextView = itemView.findViewById(R.id.textNome)
        private val textDescricao: TextView = itemView.findViewById(R.id.textDescricao)
        private val textPreco: TextView = itemView.findViewById(R.id.textPreco)
        private val imageView: ImageView = itemView.findViewById(R.id.imageViewItem)
        private val btnAdicionar: Button = itemView.findViewById(R.id.btnAdicionar)

        fun bind(menuItem: Menu) {
            setupTextViews(menuItem)
            loadImage(menuItem.imagem)
            setupAddButton(menuItem)
        }

        private fun setupTextViews(menuItem: Menu) {
            textNome.text = menuItem.nome ?: "Item sem nome"
            textDescricao.text = menuItem.descricao ?: "Descrição não disponível"
            textPreco.text = "€${String.format("%.2f", menuItem.preco ?: 0.0)}"
        }

        private fun loadImage(imageUrl: String?) {
            imageUrl?.let { url ->
                Glide.with(requireContext())
                    .load(fixImageUrl(url))
                    .placeholder(R.drawable.placeholder)
                    .error(R.drawable.error)
                    .into(imageView)
            }
        }

        private fun fixImageUrl(url: String): String {
            return url.replace("\\", "/")
        }

        private fun setupAddButton(menuItem: Menu) {
            updateButtonText(menuItem.id)
            btnAdicionar.setOnClickListener {
                adicionarAoCarrinho(menuItem)
            }
        }

        private fun updateButtonText(menuId: Int?) {
            val quantidade = CarrinhoManager.getQuantidadeItem(menuId ?: 0)
            btnAdicionar.text = if (quantidade > 0) {
                "Adicionar mais ($quantidade)"
            } else {
                "Adicionar"
            }
        }
    }

    private fun adicionarAoCarrinho(item: Menu) {
        CarrinhoManager.adicionarItem(item) { success ->
            activity?.runOnUiThread {
                if (success) {
                    showSuccessMessage(item)
                    // Não precisa mais chamar notifyDataSetChanged aqui
                    // pois o LiveData já cuida disso
                } else {
                    showError("Falha ao adicionar item")
                }
            }
        }
    }

    private fun showSuccessMessage(item: Menu) {
        val quantidade = CarrinhoManager.getQuantidadeItem(item.id ?: 0)
        Toast.makeText(
            requireContext(),
            "${item.nome} (x$quantidade) no carrinho!",
            Toast.LENGTH_SHORT
        ).show()
    }

    override fun onResume() {
        super.onResume()
        // Recarrega o carrinho ao voltar para o fragmento
        CarrinhoManager.carregarCarrinho { success ->
            if (success) {
                activity?.runOnUiThread {
                    menuAdapter?.notifyDataSetChanged()
                }
            }
        }
    }

    companion object {
        fun newInstance() = FragmentoMenu()
    }
}
