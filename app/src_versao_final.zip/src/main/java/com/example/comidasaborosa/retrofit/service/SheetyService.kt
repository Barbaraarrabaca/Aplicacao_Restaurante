package com.example.comidasaborosa.retrofit.service

import com.example.comidasaborosa.model.Menu
import retrofit2.Call
import retrofit2.http.*
// Classes para Menu
data class SheetyResponse(
    val menu: List<Menu>
)

// Classes para Utilizador/Login
data class UserResponse(
    val id: Int,
    val nome: String,
    val email: String,
    val senha: String
)

// Classe para criar usuário SEM o campo ID
data class UserCreateRequest(
    val nome: String,
    val email: String,
    val senha: String
)

data class SheetyLoginResponse(
    val utilizador: List<UserResponse>
)

// Request para criar usuário (sem ID)
data class UserCreateWrapper(
    val utilizador: UserCreateRequest
)

// Request para atualizar usuário (com ID)
data class UserUpdateWrapper(
    val utilizador: UserResponse
)

data class SheetyUserCreatedResponse(
    val utilizador: UserResponse
)

// Classes para Carrinho
data class CarrinhoItem(
    val id: Int = 0,
    val userId: Int,
    val itemId: Int,
    val nome: String,
    val preco: Double,
    val quantidade: Int = 1
)

data class CarrinhoCreateItem(
    val userId: Int,
    val itemId: Int,
    val nome: String,
    val preco: Double,
    val quantidade: Int = 1
)

data class CarrinhoUpdateItem(
    val quantidade: Int
)

data class SheetyCarrinhoRequest(
    val carrinho: CarrinhoCreateItem
)

data class SheetyCarrinhoUpdateRequest(
    val carrinho: CarrinhoUpdateItem
)

data class SheetyCarrinhoResponse(
    val carrinho: CarrinhoItem
)

data class SheetyCarrinhoListResponse(
    val carrinho: List<CarrinhoItem>
)

// Classes para Pedidos
data class Pedido(
    val id: Int = 0,
    val userId: Int,
    val dataHora: String,
    val total: Double,
    val status: String = "pendente",
    val itens: String
)

data class PedidoCreate(
    val userId: Int,
    val dataHora: String,
    val total: Double,
    val status: String = "pendente",
    val itens: String
)

data class PedidoCreateRequest(
    val pedido: PedidoCreate
)

data class PedidoUpdateRequest(
    val pedido: Pedido
)

data class SheetyPedidoResponse(
    val pedido: Pedido
)

data class SheetyPedidoListResponse(
    val pedidos: List<Pedido>
)

interface SheetyService {
    // Endpoints do Menu
    @GET("menu")
    fun getAllMenuItems(): Call<SheetyResponse>

    // Endpoints do Utilizador
    @GET("utilizador")
    fun getAllUsers(): Call<SheetyLoginResponse>

    @POST("utilizador")
    fun createUser(@Body user: UserCreateWrapper): Call<SheetyUserCreatedResponse>

    @PUT("utilizador/{id}")
    fun updateUser(@Path("id") id: Int, @Body user: UserUpdateWrapper): Call<SheetyUserCreatedResponse>

    // Endpoints do Carrinho
    @GET("carrinho")
    fun getAllCarrinhoItems(): Call<SheetyCarrinhoListResponse>

    @POST("carrinho")
    fun addItemToCarrinho(@Body request: SheetyCarrinhoRequest): Call<SheetyCarrinhoResponse>

    @PUT("carrinho/{id}")
    fun updateCarrinhoItem(
        @Path("id") id: Int,
        @Body request: SheetyCarrinhoUpdateRequest
    ): Call<SheetyCarrinhoResponse>

    @DELETE("carrinho/{id}")
    fun removeItemFromCarrinho(@Path("id") id: Int): Call<Void>

    // Endpoints dos Pedidos
    @POST("pedidos")
    fun criarPedido(@Body request: PedidoCreateRequest): Call<SheetyPedidoResponse>

    @GET("pedidos")
    fun getAllPedidos(): Call<SheetyPedidoListResponse>

    @PUT("pedidos/{id}")
    fun updatePedido(@Path("id") id: Int, @Body request: PedidoUpdateRequest): Call<SheetyPedidoResponse>
}
