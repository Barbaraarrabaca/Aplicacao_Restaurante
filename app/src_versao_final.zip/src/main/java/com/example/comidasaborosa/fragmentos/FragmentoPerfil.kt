package com.example.comidasaborosa.fragmentos

import android.app.AlertDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ScrollView
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.example.comidasaborosa.R

class FragmentoPerfil : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragmento_perfil, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Hardcoded list of unique runtime libraries from build.gradle.kts (cleaned up: latest versions, no test deps, no duplicates) [[1]]
        val libraries = listOf(
            "org.osmdroid:osmdroid-android:6.1.18",
            "androidx.preference:preference-ktx:1.2.1",
            "com.google.android.gms:play-services-location:21.0.1",
            "org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.0",  // Latest coroutines version
            "com.github.bumptech.glide:glide:4.12.0",
            "androidx.cardview:cardview:1.0.0",
            "com.squareup.retrofit2:retrofit:2.11.0",  // Latest Retrofit version
            "com.squareup.retrofit2:converter-gson:2.9.0",  // Latest converter version
            "androidx.lifecycle:lifecycle-runtime-ktx:2.6.1",
            "io.ktor:ktor-client-content-negotiation:2.0.0",
            "io.ktor:ktor-client-core:2.0.0",
            "io.ktor:ktor-client-cio:2.0.0",
            "io.ktor:ktor-client-json:2.0.0",
            "io.ktor:ktor-client-serialization:2.0.0",
            "com.squareup.okhttp3:okhttp:4.9.1",
            "com.google.code.gson:gson:2.8.8",
            "androidx.core:core-ktx:1.9.0",
            "org.jetbrains.kotlinx:kotlinx-serialization-json:1.6.0",
            "androidx.appcompat:appcompat:1.6.1",
            "com.google.android.material:material:1.11.0",  // Latest material version
            "androidx.constraintlayout:constraintlayout:2.1.4",
            "com.android.volley:volley:1.2.1",
            "androidx.privacysandbox.tools:tools-core:1.0.0-alpha09",
            "com.squareup.okhttp3:logging-interceptor:4.11.0"
        )

        // Format as a bulleted string
        val librariesText = "Bibliotecas usadas no projeto:\n" + libraries.joinToString(separator = "\n- ", prefix = "- ")

        // Set click listener on the root view to show AlertDialog
        view.setOnClickListener {
            // Create a ScrollView with TextView for scrollable content
            val scrollView = ScrollView(requireContext())
            val textView = TextView(requireContext())
            textView.text = librariesText
            textView.setPadding(32, 32, 32, 32)  // Add some padding for readability
            scrollView.addView(textView)

            // Build and show the AlertDialog
            AlertDialog.Builder(requireContext())
                .setTitle("Bibliotecas do Projeto")
                .setView(scrollView)
                .setPositiveButton("OK") { dialog, _ -> dialog.dismiss() }
                .show()
        }
    }

    companion object {
        fun newInstance() = FragmentoPerfil()
    }
}
