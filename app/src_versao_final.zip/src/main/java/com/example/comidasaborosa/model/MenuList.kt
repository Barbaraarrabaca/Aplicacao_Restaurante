package com.example.comidasaborosa.model

import com.google.gson.annotations.SerializedName

data class MenuList(
    @SerializedName("menu") val dam: List<Menu>
)

data class Menu(
    @SerializedName("id") val id: Int?,
    @SerializedName("nome") val nome: String?,
    @SerializedName("descricao") val descricao: String?,
    @SerializedName("preco") val preco: Double?,
    @SerializedName("imagem") val imagem: String?,
    @SerializedName("categoria") val categoria: String?
)