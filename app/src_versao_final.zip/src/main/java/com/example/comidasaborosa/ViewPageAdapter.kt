package com.example.comidasaborosa

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.example.comidasaborosa.fragmentos.FragmentoCarro
import com.example.comidasaborosa.fragmentos.FragmentoLocalizacao
import com.example.comidasaborosa.fragmentos.FragmentoMenu
import com.example.comidasaborosa.fragmentos.FragmentoPerfil

class ViewPagerAdapter(fragmentActivity: FragmentActivity) : FragmentStateAdapter(fragmentActivity) {

    override fun getItemCount(): Int = 4

    override fun createFragment(position: Int): Fragment {
        return when(position) {
            0 -> FragmentoPerfil.newInstance()
            1 -> FragmentoMenu.newInstance()
            2 -> FragmentoCarro.newInstance()
            3 -> FragmentoLocalizacao.newInstance()
            else -> FragmentoPerfil.newInstance()
        }
    }
}