package com.example.comidasaborosa.model

import com.google.gson.annotations.SerializedName

data class User(
    @SerializedName("nome") val name: String,
    @SerializedName("email") val email: String,
    @SerializedName("senha") val password: String
)