package com.example.comidasaborosa

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.viewpager2.widget.ViewPager2
import com.example.comidasaborosa.util.UserPreferences
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator
class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Inicializar UserPreferences com applicationContext ANTES de criar os fragmentos
        UserPreferences.init(applicationContext)

        val tabLayout: TabLayout = findViewById(R.id.tab_layout)
        val viewPager2: ViewPager2 = findViewById(R.id.view_pager2)

        // Configurar o ViewPager com offscreenPageLimit para manter todos os fragmentos em memória
        viewPager2.offscreenPageLimit = 3 // Mantém todos os 4 fragmentos carregados
        viewPager2.adapter = ViewPagerAdapter(this)

        TabLayoutMediator(tabLayout, viewPager2) { tab, position ->
            when(position) {
                0 -> {
                    tab.text = "Perfil"
                    tab.setIcon(R.drawable.baseline_person_perfil)
                }
                1 -> {
                    tab.text = "Menu"
                    tab.setIcon(R.drawable.baseline_ementa)
                }
                2 -> {
                    tab.text = "Carro"
                    tab.setIcon(R.drawable.baseline_pedidos)
                }
                3 -> {
                    tab.text = "Localização"
                    tab.setIcon(R.drawable.baseline_localizacao)
                }
            }
        }.attach()


        // Se o utilizador estiver logado, carregar o carrinho após a inicialização completa
        if (UserPreferences.isLoggedIn()) {
            CarrinhoManager.carregarCarrinho { }
        }
    }
}
