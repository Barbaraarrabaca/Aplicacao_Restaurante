package com.example.comidasaborosa

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.comidasaborosa.retrofit.RetrofitInitializer
import com.example.comidasaborosa.retrofit.service.SheetyLoginResponse
import com.example.comidasaborosa.retrofit.service.UserResponse
import com.example.comidasaborosa.util.UserPreferences
import com.example.comidasaborosa.util.ValidationUtils
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.IOException
import java.net.SocketTimeoutException

class Login : AppCompatActivity() {

    private lateinit var editTextEmail: EditText
    private lateinit var editTextPassword: EditText
    private lateinit var btnLogin: Button

    // Controlo de tentativas de login
    private var loginAttempts = 0
    private var lastAttemptTime = 0L
    private val MAX_ATTEMPTS = 3
    private val LOCKOUT_TIME = 5 * 60 * 1000L // 5 minutos

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        // Inicializar UserPreferences
        if (!UserPreferences.isInitialized()) {
            UserPreferences.init(this)
        }

        // Limpar qualquer sessão anterior
        clearUserSession()

        // Inicializar os campos de login
        editTextEmail = findViewById(R.id.inputEmail)
        editTextPassword = findViewById(R.id.inputPassword)
        btnLogin = findViewById(R.id.btnLogin)

        btnLogin.setOnClickListener {
            val email = editTextEmail.text.toString().trim()
            val password = editTextPassword.text.toString().trim()

            if (canAttemptLogin() && validateInputs(email, password)) {
                loginUser(email, password)
            }
        }

        val fazerRegistoTextView: TextView = findViewById(R.id.fazer_registo)
        fazerRegistoTextView.setOnClickListener {
            val intent = Intent(this, Registo::class.java)
            startActivity(intent)
        }

        val esqPasswordTextView: TextView = findViewById(R.id.esqPassword)
        esqPasswordTextView.setOnClickListener {
            Toast.makeText(this, "Funcionalidade em desenvolvimento", Toast.LENGTH_SHORT).show()
        }
    }

    private fun clearUserSession() {
        // Limpar dados do UserPreferences
        UserPreferences.clearUser()
    }

    private fun canAttemptLogin(): Boolean {
        val currentTime = System.currentTimeMillis()

        if (loginAttempts >= MAX_ATTEMPTS) {
            val timePassed = currentTime - lastAttemptTime
            if (timePassed < LOCKOUT_TIME) {
                val remainingTime = (LOCKOUT_TIME - timePassed) / 1000
                showError("Demasiadas tentativas. Aguarde $remainingTime segundos")
                return false
            } else {
                // Reset após o tempo de bloqueio
                loginAttempts = 0
            }
        }

        return true
    }

    private fun validateInputs(email: String, password: String): Boolean {
        var isValid = true

        // Validação de email
        if (!ValidationUtils.isValidEmail(email)) {
            editTextEmail.error = when {
                email.isEmpty() -> "Email é obrigatório"
                email.length > 100 -> "Email demasiado longo"
                else -> "Formato de email inválido"
            }
            isValid = false
        }

        // Validação de senha
        if (!ValidationUtils.isValidPassword(password)) {
            editTextPassword.error = when {
                password.isEmpty() -> "Senha é obrigatória"
                password.length < 6 -> "Senha deve ter no mínimo 6 caracteres"
                password.length > 50 -> "Senha demasiado longa"
                password.contains(" ") -> "Senha não pode conter espaços"
                else -> "Senha inválida"
            }
            isValid = false
        }

        return isValid
    }

    private fun loginUser(email: String, password: String) {
        // Desabilitar botão durante requisição
        btnLogin.isEnabled = false
        btnLogin.text = "A verificar..."

        // Sanitizar inputs
        val sanitizedEmail = ValidationUtils.sanitizeInput(email)
        val sanitizedPassword = ValidationUtils.sanitizeInput(password)

        // Buscar TODOS os utilizadores (Sheety não suporta filtros)
        val call = RetrofitInitializer().sheetyService().getAllUsers()

        // Logs detalhados para debug
        Log.d("Login", "Tentando fazer login com email: $sanitizedEmail")
        Log.d("Login", "URL: ${call.request().url}")
        Log.d("Login", "Headers: ${call.request().headers}")
        Log.d("Login", "Method: ${call.request().method}")

        call.enqueue(object : Callback<SheetyLoginResponse> {
            override fun onResponse(call: Call<SheetyLoginResponse>, response: Response<SheetyLoginResponse>) {
                btnLogin.isEnabled = true
                btnLogin.text = getString(R.string.btn_login)

                Log.d("Login", "Resposta recebida - Código: ${response.code()}")
                Log.d("Login", "Headers da resposta: ${response.headers()}")

                when {
                    response.isSuccessful -> {
                        val loginResponse = response.body()
                        Log.d("Login", "Número de utilizadores encontrados: ${loginResponse?.utilizador?.size ?: 0}")

                        if (loginResponse != null && loginResponse.utilizador.isNotEmpty()) {
                            // Procurar utilizador com email e senha correspondentes
                            val user = loginResponse.utilizador.find { user ->
                                user.email.equals(sanitizedEmail, ignoreCase = true) &&
                                        user.senha == sanitizedPassword
                            }

                            if (user != null) {
                                // Reset tentativas após login bem-sucedido
                                loginAttempts = 0

                                Toast.makeText(this@Login, "Login bem-sucedido!", Toast.LENGTH_LONG).show()

                                // Salvar dados do utilizador usando UserPreferences
                                saveTemporaryUserData(user)

                                // Limpar campos
                                editTextEmail.text.clear()
                                editTextPassword.text.clear()

                                // Redirecionar após um pequeno delay
                                btnLogin.postDelayed({
                                    val intent = Intent(this@Login, MainActivity::class.java)
                                    startActivity(intent)
                                    finish()
                                }, 1000)
                            } else {
                                loginAttempts++
                                lastAttemptTime = System.currentTimeMillis()
                                showError("Email ou senha incorretos")
                                Log.d("Login", "Utilizador não encontrado com essas credenciais")
                            }
                        } else {
                            showError("Nenhum utilizador registado no sistema")
                            Log.w("Login", "Lista de utilizadores vazia")
                        }
                    }
                    response.code() == 400 -> {
                        val errorBody = response.errorBody()?.string()
                        Log.e("Login", "Erro 400 - Bad Request. Body: $errorBody")
                        showError("Erro na requisição. Verifique a configuração da API.")
                    }
                    response.code() == 401 || response.code() == 403 -> {
                        Log.e("Login", "Erro de autenticação: ${response.code()}")
                        showError("Erro de autenticação. Verifique a configuração da API.")
                    }
                    response.code() == 404 -> {
                        Log.e("Login", "Endpoint não encontrado")
                        showError("Serviço não encontrado. Verifique a URL da API.")
                    }
                    response.code() == 429 -> {
                        Log.e("Login", "Rate limit excedido")
                        showError("Demasiadas tentativas. Tente novamente mais tarde")
                    }
                    response.code() == 500 -> {
                        Log.e("Login", "Erro interno do servidor")
                        showError("Erro no servidor. Tente novamente mais tarde")
                    }
                    else -> {
                        val errorBody = response.errorBody()?.string()
                        Log.e("Login", "Erro ${response.code()} - Body: $errorBody")
                        showError("Erro no servidor: ${response.code()}")
                    }
                }
            }

            override fun onFailure(call: Call<SheetyLoginResponse>, t: Throwable) {
                btnLogin.isEnabled = true
                btnLogin.text = getString(R.string.btn_login)

                Log.e("Login", "Falha na conexão: ${t.message}", t)

                val errorMessage = when {
                    t is SocketTimeoutException -> "Tempo de conexão esgotado"
                    t is IOException -> {
                        if (t.message?.contains("failed to connect", true) == true) {
                            "Não foi possível conectar ao servidor"
                        } else {
                            "Sem conexão com a internet"
                        }
                    }
                    else -> "Erro de conexão: ${t.localizedMessage}"
                }

                showError(errorMessage)
            }
        })
    }

    private fun showError(message: String) {
        Toast.makeText(this@Login, message, Toast.LENGTH_LONG).show()
    }

    private fun saveTemporaryUserData(user: UserResponse) {
        // Usar UserPreferences para salvar os dados do utilizador
        UserPreferences.saveUser(user.id, user.nome, user.email)
        Log.d("Login", "Dados do utilizador salvos: ID=${user.id}, Nome=${user.nome}")
    }

    override fun onDestroy() {
        super.onDestroy()
        // Limpar dados sensíveis quando a activity for destruída
        editTextEmail.text.clear()
        editTextPassword.text.clear()
    }
}
