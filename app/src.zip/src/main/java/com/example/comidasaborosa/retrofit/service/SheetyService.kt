package com.example.comidasaborosa.retrofit.service

import com.example.comidasaborosa.Model.User
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Query
// Wrapper para o request
data class SheetyUserRequest(
    val utilizador: User
)

// Wrapper para a resposta
data class SheetyUserResponse(
    val utilizador: UserResponse
)

data class SheetyLoginResponse(
    val utilizador: List<UserResponse>
)

data class UserResponse(
    val id: Int,
    val nome: String,
    val email: String,
    val senha: String
)

interface SheetyService {
    // IMPORTANTE: Remova a acentuação da URL
    @POST("2e0d44beddc7cf3e39dc567d307645f2/dam/utilizador")
    fun registerUser(@Body request: SheetyUserRequest): Call<SheetyUserResponse>

    @GET("2e0d44beddc7cf3e39dc567d307645f2/dam/utilizador")
    fun loginUser(
        @Query("email") email: String,
        @Query("senha") password: String
    ): Call<SheetyLoginResponse>

}
