package com.example.comidasaborosa

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.comidasaborosa.Model.User
import com.example.comidasaborosa.retrofit.RetrofitInitializer
import com.example.comidasaborosa.retrofit.service.SheetyUserRequest
import com.example.comidasaborosa.retrofit.service.SheetyUserResponse
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class Registo : AppCompatActivity() {

    private lateinit var editTextName: EditText
    private lateinit var editTextEmail: EditText
    private lateinit var editTextPassword: EditText
    private lateinit var btnRegister: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registo)

        // Inicializar os campos de entrada
        editTextName = findViewById(R.id.inputUserName)
        editTextEmail = findViewById(R.id.inputEmail)
        editTextPassword = findViewById(R.id.inputPassword)
        btnRegister = findViewById(R.id.btnRegisto)

        btnRegister.setOnClickListener {
            val name = editTextName.text.toString().trim()
            val email = editTextEmail.text.toString().trim()
            val password = editTextPassword.text.toString().trim()

            if (validateInputs(name, email, password)) {
                registerUser(name, email, password)
            }
        }

        // Texto para fazer login
        val fazerLoginTextView: TextView = findViewById(R.id.conta)
        fazerLoginTextView.setOnClickListener {
            val intent = Intent(this, Login::class.java)
            startActivity(intent)
        }
    }

    private fun validateInputs(name: String, email: String, password: String): Boolean {
        if (name.isEmpty()) {
            editTextName.error = "Nome é obrigatório"
            return false
        }

        if (email.isEmpty() || !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            editTextEmail.error = "Email inválido"
            return false
        }

        if (password.length < 6) {
            editTextPassword.error = "Senha deve ter pelo menos 6 caracteres"
            return false
        }

        return true
    }

    private fun registerUser(name: String, email: String, password: String) {
        val user = User(name, email, password)
        val request = SheetyUserRequest(user)

        Log.d("Registo", "Enviando registro para Sheety...")

        val call = RetrofitInitializer().sheetyService().registerUser(request)

        call.enqueue(object : Callback<SheetyUserResponse> {
            override fun onResponse(call: Call<SheetyUserResponse>, response: Response<SheetyUserResponse>) {
                Log.d("Registo", "Resposta recebida - Código: ${response.code()}")

                if (response.isSuccessful) {
                    Log.d("Registo", "Registro bem-sucedido!")
                    val userResponse = response.body()
                    Log.d("Registo", "Dados retornados: ${userResponse?.utilizador}")

                    Toast.makeText(this@Registo, "Registro realizado com sucesso!", Toast.LENGTH_SHORT).show()
                    // Redirecionar para o login
                    val intent = Intent(this@Registo, Login::class.java)
                    startActivity(intent)
                    finish()
                } else {
                    val errorBody = response.errorBody()?.string()
                    Log.e("Registo", "Erro no registro - Código: ${response.code()}, Erro: $errorBody")
                    Toast.makeText(
                        this@Registo,
                        "Erro no registro: $errorBody",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }

            override fun onFailure(call: Call<SheetyUserResponse>, t: Throwable) {
                Log.e("Registo", "Falha na conexão", t)
                Toast.makeText(
                    this@Registo,
                    "Falha na conexão: ${t.message}",
                    Toast.LENGTH_SHORT
                ).show()
            }
        })
    }
}
