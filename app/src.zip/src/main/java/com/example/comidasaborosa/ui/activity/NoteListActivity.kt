package com.example.comidasaborosa.ui.activity

    import retrofit2.Call
    import retrofit2.Callback

private fun <T, Note> Call<T>.enqueue(callback: Callback<List<Note>?>) {

}
