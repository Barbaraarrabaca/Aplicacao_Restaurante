package com.example.comidasaborosa.retrofit.service

import com.example.comidasaborosa.Model.MenuResponse
import retrofit2.Call
import retrofit2.http.GET

interface MenuService {
    @GET("2e0d44beddc7cf3e39dc567d307645f2/dam/menu")
    fun getMenu(): Call<MenuResponse> // Corrigido para MenuResponse
}