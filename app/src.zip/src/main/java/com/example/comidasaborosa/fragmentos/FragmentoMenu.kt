package com.example.comidasaborosa.fragmentos

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.comidasaborosa.CarrinhoManager
import com.example.comidasaborosa.Model.Menu
import com.example.comidasaborosa.Model.MenuResponse
import com.example.comidasaborosa.R
import com.example.comidasaborosa.retrofit.service.MenuService
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class FragmentoMenu : Fragment() {

    private lateinit var recyclerView: RecyclerView
    private var menuList = mutableListOf<Menu>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragmento_menu, container, false)
        recyclerView = view.findViewById(R.id.recyclerViewMenu)
        recyclerView.layoutManager = LinearLayoutManager(context)
        recyclerView.setHasFixedSize(true)

        loadMenuItems()

        return view
    }

    private fun loadMenuItems() {
        val retrofit = Retrofit.Builder()
            .baseUrl("https://api.sheety.co/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
        //Log.e("API_FAILURE", "Falha na chamada à API", retrofit.toString())
        val service = retrofit.create(MenuService::class.java)
        val call = service.getMenu()

        call.enqueue(object : Callback<MenuResponse> {
            override fun onResponse(call: Call<MenuResponse>, response: Response<MenuResponse>) {
                if (response.isSuccessful) {
                    val menuResponse = response.body()

                    Log.d("SHEETY_MENU_DATA", "Dados recebidos: ${menuResponse.toString()}")


                    menuResponse?.dam?.let { items ->
                        menuList.clear()
                        menuList.addAll(items)
                        recyclerView.adapter = MenuAdapter(menuList)
                    }
                } else {
                    Toast.makeText(
                        requireContext(),
                        "Erro na resposta: ${response.code()}",
                        Toast.LENGTH_SHORT
                    ).show()
                    Log.e("API_RESPONSE", "Código de erro: ${response.code()}")
                }
            }

            override fun onFailure(call: Call<MenuResponse>, t: Throwable) {
                Toast.makeText(
                    requireContext(),
                    "Falha na conexão: ${t.message}",
                    Toast.LENGTH_SHORT
                ).show()
                Log.e("API_FAILURE", "Falha na chamada à API", t)
            }
        })
    }

    inner class MenuAdapter(private val items: List<Menu>) : RecyclerView.Adapter<MenuViewHolder>() {
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MenuViewHolder {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_menu, parent, false)
            return MenuViewHolder(view)
        }

        override fun onBindViewHolder(holder: MenuViewHolder, position: Int) {
            holder.bind(items[position])
        }

        override fun getItemCount() = items.size
    }

    inner class MenuViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        fun bind(menuItem: Menu) {
            itemView.findViewById<TextView>(R.id.textNome).text = menuItem.nome ?: ""
            itemView.findViewById<TextView>(R.id.textDescricao).text = menuItem.descricao ?: ""
            itemView.findViewById<TextView>(R.id.textPreco).text =
                "€${String.format("%.2f", menuItem.preco ?: 0.0)}"

            val imageView = itemView.findViewById<ImageView>(R.id.imageViewItem)
            // Corrigir URL da imagem: substituir barras invertidas
            val imageUrl = menuItem.imagem?.replace("\\", "/")
            Glide.with(requireContext())
                .load(imageUrl)
                .placeholder(R.drawable.placeholder)
                .error(R.drawable.error)
                .into(imageView)

            itemView.findViewById<Button>(R.id.btnAdicionar).setOnClickListener {
                adicionarAoCarrinho(menuItem)
            }
        }
    }

    private fun adicionarAoCarrinho(item: Menu) {
        CarrinhoManager.adicionarItem(item)
        Toast.makeText(
            requireContext(),
            "${item.nome} adicionado ao carrinho!",
            Toast.LENGTH_SHORT
        ).show()
    }

    companion object {
        fun newInstance() = FragmentoMenu()
    }
}