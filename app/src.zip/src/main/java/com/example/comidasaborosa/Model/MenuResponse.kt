package com.example.comidasaborosa.Model

import com.google.gson.annotations.SerializedName

data class MenuResponse(
    @SerializedName("menu") val dam: List<Menu> // Nome do grupo na planilha
)

data class Menu(
    @SerializedName("id") val id: Int?,
    @SerializedName("nome") val nome: String?,
    @SerializedName("descricao") val descricao: String?,
    @SerializedName("preco") val preco: Double?,
    @SerializedName("imagem") val imagem: String?,
    @SerializedName("categoria") val categoria: String?
)