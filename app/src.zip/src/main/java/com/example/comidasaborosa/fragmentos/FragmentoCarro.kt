package com.example.comidasaborosa.fragmentos

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.comidasaborosa.CarrinhoManager
import com.example.comidasaborosa.Model.Menu
import com.example.comidasaborosa.R
class FragmentoCarro : Fragment() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var textTotal: TextView
    private lateinit var btnFinalizar: Button

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragmento_carro, container, false)

        recyclerView = view.findViewById(R.id.recyclerViewCarrinho)
        recyclerView.layoutManager = LinearLayoutManager(context)

        textTotal = view.findViewById(R.id.textTotal)
        btnFinalizar = view.findViewById(R.id.btnFinalizar)

        btnFinalizar.setOnClickListener {
            finalizarCompra()
        }

        atualizarCarrinho()

        return view
    }

    override fun onResume() {
        super.onResume()
        atualizarCarrinho()
    }

    private fun atualizarCarrinho() {
        val itens = CarrinhoManager.getItens()
        recyclerView.adapter = CarrinhoAdapter(itens)
        textTotal.text = "Total: €${String.format("%.2f", CarrinhoManager.calcularTotal())}"
    }

    inner class CarrinhoAdapter(private val items: List<Menu>) : RecyclerView.Adapter<CarrinhoViewHolder>() {
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CarrinhoViewHolder {
            val view = LayoutInflater.from(parent.context).inflate(R.layout.item_carrinho, parent, false)
            return CarrinhoViewHolder(view)
        }

        override fun onBindViewHolder(holder: CarrinhoViewHolder, position: Int) {
            holder.bind(items[position])
        }

        override fun getItemCount() = items.size
    }

    inner class CarrinhoViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        fun bind(`aMenu-oldItem`: Menu) {
            itemView.findViewById<TextView>(R.id.textNome).text = `aMenu-oldItem`.nome
            itemView.findViewById<TextView>(R.id.textPreco).text = "€${String.format("%.2f", `aMenu-oldItem`.preco)}"

            itemView.findViewById<Button>(R.id.btnRemover).setOnClickListener {
                CarrinhoManager.removerItem(`aMenu-oldItem`)
                atualizarCarrinho()
            }
        }
    }

    private fun finalizarCompra() {
        if (CarrinhoManager.getItens().isEmpty()) {
            Toast.makeText(context, "Carrinho vazio", Toast.LENGTH_SHORT).show()
            return
        }

        // Implementar lógica de finalização (pagamento, etc.)
        Toast.makeText(context, "Compra finalizada! Obrigado.", Toast.LENGTH_SHORT).show()
        CarrinhoManager.limparCarrinho()
        atualizarCarrinho()
    }

    companion object {
        fun newInstance() = FragmentoCarro()
    }
}