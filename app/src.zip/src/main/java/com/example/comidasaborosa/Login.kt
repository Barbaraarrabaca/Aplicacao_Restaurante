package com.example.comidasaborosa

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.comidasaborosa.retrofit.RetrofitInitializer
import com.example.comidasaborosa.retrofit.service.SheetyLoginResponse
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class Login : AppCompatActivity() {

    private lateinit var editTextEmail: EditText
    private lateinit var editTextPassword: EditText
    private lateinit var btnLogin: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        // Inicializar os campos de login
        editTextEmail = findViewById(R.id.inputEmail)
        editTextPassword = findViewById(R.id.inputPassword)
        btnLogin = findViewById(R.id.btnLogin)

        btnLogin.setOnClickListener {
            val email = editTextEmail.text.toString().trim()
            val password = editTextPassword.text.toString().trim()

            if (validateInputs(email, password)) {
                loginUser(email, password)
            }
        }

        val fazerRegistoTextView: TextView = findViewById(R.id.fazer_registo)
        fazerRegistoTextView.setOnClickListener {
            val intent = Intent(this, Registo::class.java)
            startActivity(intent)
        }
    }

    private fun validateInputs(email: String, password: String): Boolean {
        if (email.isEmpty() || !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            editTextEmail.error = "Email inválido"
            return false
        }

        if (password.isEmpty()) {
            editTextPassword.error = "Senha é obrigatória"
            return false
        }

        return true
    }

    private fun loginUser(email: String, password: String) {
        val call = RetrofitInitializer().sheetyService().loginUser(email, password)

        call.enqueue(object : Callback<SheetyLoginResponse> {
            override fun onResponse(call: Call<SheetyLoginResponse>, response: Response<SheetyLoginResponse>) {
                if (response.isSuccessful) {
                    val loginResponse = response.body()
                    if (loginResponse != null && loginResponse.utilizador.isNotEmpty()) {
                        // Login bem-sucedido
                        Toast.makeText(this@Login, "Login bem-sucedido!", Toast.LENGTH_SHORT).show()

                        // Redirecionar para MainActivity
                        val intent = Intent(this@Login, MainActivity::class.java)
                        startActivity(intent)
                        finish()
                    } else {
                        Toast.makeText(this@Login, "Credenciais inválidas", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    Toast.makeText(this@Login, "Erro no login", Toast.LENGTH_SHORT).show()
                    Log.e("Login", "Erro: ${response.errorBody()?.string()}")
                }
            }

            override fun onFailure(call: Call<SheetyLoginResponse>, t: Throwable) {
                Toast.makeText(this@Login, "Falha na conexão: ${t.message}", Toast.LENGTH_SHORT).show()
                Log.e("Login", "Falha na conexão", t)
            }
        })
    }
}