package com.example.comidasaborosa.Model

import com.google.gson.annotations.SerializedName

data class User(
    @SerializedName("nome") val name: String,
    @SerializedName("email") val email: String,
    @SerializedName("senha") val password: String
)