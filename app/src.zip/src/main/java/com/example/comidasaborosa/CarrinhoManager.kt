package com.example.comidasaborosa

import com.example.comidasaborosa.Model.Menu

object CarrinhoManager {
    private val itensCarrinho = mutableListOf<Menu>()

    fun adicionarItem(item: Menu) {
        itensCarrinho.add(item)
    }

    fun removerItem(item: Menu) {
        itensCarrinho.remove(item)
    }

    fun getItens(): List<Menu> {
        return itensCarrinho.toList()
    }

    fun calcularTotal(): Double {
        return itensCarrinho.sumOf { it.preco ?: 0.0 }
    }

    fun limparCarrinho() {
        itensCarrinho.clear()
    }
}